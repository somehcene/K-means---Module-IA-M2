
from pandas import read_csv
from sklearn.preprocessing import MinMaxScaler, StandardScaler 
from matplotlib.pyplot import scatter, figure, grid, legend, xlabel, ylabel, title, show, plot
from sklearn.cluster import KMeans 
from elbow import elbow
from autoelbow_rupakbob import autoelbow
import numpy as np



dataApp = read_csv("C:/Users/pc/Desktop/M2 ACTUAL/IA/DM IA/DataApp.csv", index_col=0)
dataEval = read_csv("C:/Users/pc/Desktop/M2 ACTUAL/IA/DM IA/DataEval.csv", index_col=0)

#Determination du nombre de clusters optimal 

sseApp=elbow(dataApp)
#sseEval=elbow(12, dataEval)

#Apprentissage
norm=MinMaxScaler()
dataAppnorm=dataApp
dataAppnorm[['Fréquence', 'Puissance']] = norm.fit_transform(dataAppnorm[['Fréquence', 'Puissance']])
k_means=KMeans(n_clusters=4)  
model = k_means.fit(dataAppnorm)
y_clusterApp=model.predict(dataAppnorm)
dataAppnorm["Cluster"] = y_clusterApp

figure()
sc=scatter(dataAppnorm['Fréquence'], dataAppnorm['Puissance'], c=dataAppnorm["Cluster"], alpha=0.7)
lp = lambda i: plot([],color=sc.cmap(sc.norm(i)), label="cluster {:g}".format(i), ls="", marker="o")[0]
handles = [lp(i) for i in np.unique(dataAppnorm["Cluster"])]
legend(handles=handles)
title("données clssifiées en clusters sans normalisation")
xlabel("Fréquence") 
ylabel("puissane")
centroidClusters = k_means.cluster_centers_ 
scatter(centroidClusters[:,0], centroidClusters[:,1], color='red',label='Centroide')


#Evaluation
dataEvalnorm=dataEval 
dataEvalnorm[['Fréquence', 'Puissance']] = norm.fit_transform(dataEvalnorm[['Fréquence', 'Puissance']])
y_clusterEval=model.predict(dataEvalnorm)
dataEvalnorm["Cluster"] = y_clusterEval

figure()
sc=scatter(dataEvalnorm['Fréquence'], dataEvalnorm['Puissance'], c=dataEvalnorm["Cluster"], alpha=0.7)
lp = lambda i: plot([],color=sc.cmap(sc.norm(i)), label="cluster {:g}".format(i), ls="", marker="o")[0]
handles = [lp(i) for i in np.unique(dataEvalnorm["Cluster"])]
legend(handles=handles)
title("données clssifiées en clusters sans normalisation")
xlabel("Fréquence") 
ylabel("puissane")
scatter(centroidClusters[:,0], centroidClusters[:,1], color='red',label='Centroide')
















