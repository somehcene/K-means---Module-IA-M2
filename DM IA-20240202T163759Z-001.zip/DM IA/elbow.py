






from matplotlib.pyplot import scatter, figure, grid, legend, xlabel, ylabel, title, show, plot
from sklearn.cluster import KMeans 

def elbow(data):
    k_plage = range(2,12) 
    sse = []
    for i in k_plage: 
        k_means=KMeans(i)
        y_cluster = k_means.fit_predict(data)
        #data["Cluster"] = y_cluster
        sse.append(k_means.inertia_)

    figure()
    plot(k_plage, sse, "m--")
    scatter(k_plage, sse, marker="+", color="r")
    title("Inertie en fonction du nobmre de clusters")
    xlabel("Nombre de clusters") 
    ylabel("Inertie")
    grid(color='r', linestyle='--', linewidth=0.5)
    
    return sse
    

    